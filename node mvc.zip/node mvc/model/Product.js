
const db = require("../config/database");
var  get, all;
class ProductModel {

    static async all() {
        try {
            const flags = db.query("SELECT * FROM products");
            return flags[1];
        } catch (error) { console.log("err");
            // throw error;
           
        }
        // return new Promise((resolve,reject) => {
        //     db.query("SELECT * FROM p.roducts", (err, result, fields) => {
        //         if (err){
        //         //    return reject({error:"failed"}); 
        //            console.log("err");
        //             // throw (err.sqlMessage);
        //         } 
        //        return resolve(result);
        //     });
        // });
    }



    static async find(id) {
        return new Promise(resolve => {
            db.query("SELECT * FROM products where id =" + id, (err, result, fields) => {
                if (err) throw (err.sqlMessage);
                resolve(result);
            });
        });
    }

    static async save(req) {
        console.log(req.name);
        return new Promise(resolve => {
            let inqr = " INSERT INTO produpcts(pname, price) VALUES ("+req.name+","+req.price+") ";
                db.query(inqr,(err,result)=>{
                    if(!err){
                        resolve({ success: "operation complete" });
                    }else{
                        resolve({ error: "operation failed" });
                    }
                    
                });
                
        });
    }



}

module.exports = ProductModel;