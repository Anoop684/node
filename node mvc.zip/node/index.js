var express = require("express");
var app = express();
var jwt = require("jsonwebtoken");

var blacklist = require("express-jwt-blacklist");

var mysql = require("mysql");
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "node"
});
con.connect((err) => {
    if (err) {
        throw err.sqlMessage;
    }
    console.log('connected');
});


var bodyParser = require("body-parser");
// json parser
var jsonParser = bodyParser.json();

// url encoded 
var urlEncodedParser = bodyParser.urlencoded({ extended: false });
var cors = require("cors");
app.use(cors());

//middleware

function verifyToken(req, res, next) {
    let authHeader = req.headers.authorization;
    if (authHeader == undefined) {
        res.status(401).send({ error: "no token provided" })
    }
    let token = authHeader.split(" ")[1];
    jwt.verify(token, "secret", (err, decoded) => {
        if (err) {
            // console.log(err);
            res.status(500).send({ error: "Authentication faled" });
        } else {
            // res.status(200).send(decoded);
            next();
        }

    });
}


app.get("/", (req, res) => {
    res.send("<h1>welcome</h1>");
});


//Authentication using jwt
app.post("/login", jsonParser, (req, res) => {
    let username = req.body.username;
    let password = req.body.password;
    if (username == undefined || password == undefined) {
        res.status(500).send({ error: "Authentication failed" });
    }
    let login = `SELECT name FROM login WHERE username='${username}' AND password = SHA1('${password}')`;
    con.query(login, (err, result) => {
        if (err || result.length == 0) {
            console.log(err);
            res.status(500).send({ error: "login error" });
        } else {
            let response = {
                id: result[0].id,
                dname: result[0].name
            }
            let token = jwt.sign(response, "secret", { expiresIn: 86400 });
            res.status(200).send({ auth: true, token: token, success: "login success" });
        }
    })
});

//get all product
app.get("/products", verifyToken, function (req, res) {

    con.query("SELECT * FROM products", (err, result, fields) => {
        if (err) throw (err);
        console.log(result);
        res.send(result);
    });

});

// get one product
app.get("/products/:id", verifyToken, function (req, res) {
    let id = req.params.id;
    con.query("SELECT * FROM products where id =" + id, (err, result, fields) => {
        if (err) throw (err);
        console.log(result);
        res.send(result);
    });

});

//save product
app.post("/product", verifyToken, jsonParser, async function (req, res) {
    let pname = req.body.pname;
    let price = req.body.price;
    let inqr = ` INSERT INTO products(pname, price) VALUES ('${pname}','${price}') `;
    /*con.query(inqr,(err,result)=>{
        if(err){
            res.send({error:"operation failed"});
        }else{
            res.send({success:"operation complete"});
        }
    });*/
    try {
        const result = await con.query(inqr);
        res.send({ success: "operation complete" })
    } catch (e) {
        console.log(e);
        res.send({ error: "operation failed" });
    }

});

//update product
app.patch("/product/:id", verifyToken, jsonParser, async function (req, res) {
    let pname = req.body.pname;
    let price = req.body.price;
    let id = req.params.id;
    let upqr = ` UPDATE products SET pname='${pname}',price='${price}' WHERE id = '${id}' `;
    /*con.query(upqr, (err, result) => {
        if (err) {
            // console.log(err);
            res.send({ error: "operation failed" });
        } else {
            res.send({ success: "operation complete" });
        }
    });*/
    try {
        const result = await con.query(upqr);
        res.send({ success: "operation complete" })
    } catch (e) {
        console.log(e);
        res.send({ error: "operation failed" });
    }

});

//delete product
app.delete("/product/:id", verifyToken, async function (req, res) {
    let id = req.params.id;
    let dlqr = ` DELETE FROM products WHERE id = '${id}' `;
    /*con.query(dlqr, (err, result) => {
        if (err) {
            res.send({ error: "operation failed" });
        } else {
            res.send({ success: "operation complete" });
        }
    });*/
    try {
        const result = await con.query(dlqr);
        res.send({ success: "operation complete" })
    } catch (e) {
        console.log(e);
        res.send({ error: "operation failed" });
    }
});

//logout using jwt blacklist
app.get('/logout', function (req, res) {
    try {
        let token = req.headers.authorization.split(" ")[1];

        let decodedTocken = jwt.decode(token);

        blacklist.revoke(decodedTocken.jti, { expiresIn: decodedTocken.exp - Date.now() });
        res.redirect('/');
        res.status(200).send("Logout successful");
        
    } catch (err) {
        // console.log(err);
        res.status(500).json({
            status: 'error',
            message: 'Internal Server Error',
        });
    }

});

app.listen(3000, () => {
    console.log('server started');
});
