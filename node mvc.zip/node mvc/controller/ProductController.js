const Product = require("../model/Product");

class ProductController{

    static async getAllProduct(req,res){
       var results = await Product.all();
       if(results){
        res.send(results);
       }
    }

    static async getone(req,res){
        let id = req.params.id;
        var results = await Product.find(id);
        if(results){
         res.send(results);
        }
     }

     static async add(req,res){
        let values = {name: req.body.pname, price: req.body.price};
        var results = await Product.save(values);
        if(results){
         res.send(results);
        }
     }
}


module.exports=ProductController;