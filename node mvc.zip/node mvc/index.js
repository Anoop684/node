const express = require("express");
const app = express();
const route = require("./routes/web");
const cookieParser = require('cookie-parser');

app.use(cookieParser());

var cors = require("cors");

app.use(cors());

app.use('/', route);

app.listen(3000, () => {
    console.log("server running");
})