var jwt = require("jsonwebtoken");
const Model = require("../model/Model");

const crypto = require('crypto');
const shasum = crypto.createHash('sha1');

class UserController {


    static async signup(req, res) {

        // sha1 encryption
        try {
            let password = shasum.update(JSON.stringify(req.body.password)).digest('hex');

            let data = { name: `'${req.body.name}'`, username: `'${req.body.name}'`, password: `'${password}'` };
            var results = await Model.save('login', data);
            if (results) {
                res.send(results);
            }
        } catch (error) {
            res.send({ error: "registration failed" });
        }

    }

    static async login(req, res) {

        let username = req.body.username;
        let password = shasum.update(JSON.stringify(req.body.password)).digest('hex');
        if (username == undefined || password == undefined) {
            res.status(500).send({ error: "Authentication failed" });
        }
        let cond = ` username = '${username}' AND password = '${password}' `;

        try {

            var result = await Model.signIn('login', cond);
            let response = {
                id: result[0].id,
                displayname: result[0].name
            }
            let token = jwt.sign(response, "secret");
            res.cookie('token', token, { httpOnly: true })

            res.status(200).send({ auth: true, token: token, success: "login success" });

        } catch (error) {
            throw error;
            res.status(500).send({ error: "login error" });
        }

        // res.end();
    }

    static async logout(req, res) {
        try {
            res.clearCookie('token');
            res.send({ success: 'Logout successful' });
        } catch (error) {
            res.send({ error: 'Logout error' });
        }

    }

}

module.exports = UserController;