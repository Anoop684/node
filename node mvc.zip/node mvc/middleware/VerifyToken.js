var jwt = require("jsonwebtoken");
// const dd = require('dump-die')
class Jwt {

    static async verifyToken(req, res, next) {
        const cooToken = req.cookies.token;
        let authHeader = req.headers.authorization;
        if (authHeader == undefined || cooToken == undefined) {
            res.status(401).send({ error: "no token provided" })
        }
        let token = authHeader.split(" ")[1];
        jwt.verify(token, "secret", (err, decoded) => {
            if (err) {
                // console.log(err);
                res.status(500).send({ error: "Authentication failed" });
            } else {
                // res.status(200).send(decoded);
                next();
            }

        });
    }

}

module.exports = Jwt;