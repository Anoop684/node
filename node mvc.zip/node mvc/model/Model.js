
const db = require("../config/database");
// const dd = require('dump-die');

class Model {


    static async signIn(table, cond) {

        return new Promise(resolve => {

            let login = `SELECT * FROM ${table} WHERE ${cond}`;

            db.query(login, (err, result, fields) => {
                if (err) {
                    //    return reject({error:"failed"}); 
                    console.log("err");
                    res.status(500).send({ error: "login error" });
                }
                return resolve(result);
            });
        });

    }

    static async all(table) {

        return new Promise(resolve => {
            db.query("SELECT * FROM " + table, (err, result, fields) => {
                if (err) {
                    //    return reject({error:"failed"}); 
                    console.log("err");
                    // throw (err.sqlMessage);
                }
                return resolve(result);
            });
        });

    }

    static async findById(table, id) {
        return new Promise(resolve => {
            db.query("SELECT * FROM " + table + " where id =" + id, (err, result, fields) => {
                if (err) throw (err.sqlMessage);
                resolve(result);
            });
        });
    }

    static async save(table, data) {

        return new Promise(resolve => {
            let inqr = " INSERT INTO " + table + "(" + Object.keys(data) + ") VALUES (" + Object.values(data) + ") ";
            db.query(inqr, (err, result) => {
                if (!err) {
                    resolve({ success: "operation complete" });
                } else {
                    // throw err;
                    resolve({ error: "operation failed" });
                }

            });
        });
    }

    static async update(table, data, id) {

        var val = [];
        for (const [key, value] of Object.entries(data)) {
            val.push(`${key} = ${value}`);
        }

        return new Promise(resolve => {
            let updqr = " UPDATE " + table + " SET " + val + " WHERE id =  " + id;
            db.query(updqr, (err, result) => {
                if (!err) {
                    resolve({ success: "operation complete" });
                } else {
                    // throw err;
                    resolve({ error: "operation failed" });
                }

            });

        });
    }

    static async delete(table, id) {
        return new Promise(resolve => {
            db.query(" DELETE FROM " + table + " where id =" + id, (err, result, fields) => {
                if (!err) {
                    resolve({ success: "operation complete" });
                } else {
                    resolve({ error: "operation failed" });
                };

            });
        });
    }

}

module.exports = Model;