const Model = require("../model/Model");

class ProductController {

   static async getAll(req, res) {
      try {
         var results = await Model.all('products');
         if (results) {
            res.send(results);
         }
      } catch (error) {
         res.send({ error: "Error fetching data" });
      }

   }

   static async getOne(req, res) {
      try {
         var results = await Model.findById('products', req.params.id);
         if (results) {
            res.send(results);
         }
      } catch (error) {
         res.send({ error: "Error fetching this data" });
      }

   }

   static async add(req, res) {
      try {
         let data = { pname: `'${req.body.pname}'`, price: req.body.price };
         var results = await Model.save('products', data);
         if (results) {
            res.send(results);
         }
      } catch (error) {
         res.send({ error: "Error storing data" });
      }

   }

   static async update(req, res) {
      try {
         let data = { pname: `'${req.body.pname}'`, price: req.body.price };
         var results = await Model.update('products', data, req.params.id);
         if (results) {
            res.send(results);
         }
      } catch (error) {
         res.send({ error: "Error updating data" });
      }

   }

   static async delete(req, res) {
      try {
         var results = await Model.delete('products', req.params.id);
         if (results) {
            res.send(results);
         }
      } catch (error) {
         res.send({ error: "Error deleting data" });
      }

   }

}


module.exports = ProductController;