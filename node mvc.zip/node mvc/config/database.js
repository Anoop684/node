const mysql = require("mysql");

var db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "node"
});
db.connect((err) => {
    if (err) {
        throw err.sqlMessage;
    }
    console.log('connected');
});

module.exports = db;