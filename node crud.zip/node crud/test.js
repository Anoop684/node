
var mysql = require("mysql");

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "node"
});
con.connect((err) => {
    if (err) {
        throw err.sqlMessage;
    }
    console.log('connected');
});



let inqr = `INSERT INTO products(pname, price) VALUES ('new2',6)` ;
    con.query(inqr,(err,result)=>{
        if(err){
            console.log(err);
        }else{
            res.send({success:"operation complete"});
        }
    });