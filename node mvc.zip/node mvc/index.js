const express = require("express");
const app = express();
const db = require("./config/database");
const route = require("./routes/web");


app.use('/products', route);




app.listen(3000, () => {
    console.log("server running");
})