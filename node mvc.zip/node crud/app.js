
var express = require("express");
var app = express();


const MySQLCrud = require('db');

const dbConfig = {
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'node',
};

const crud = new MySQLCrud(dbConfig);

crud.connect();


//var db = require('db');

var bodyParser = require("body-parser");

// json parser
var jsonParser = bodyParser.json;

// url encoded 
var urlEncodedParser = bodyParser.urlencoded({extended:false});
var cors = require("cors");
app.use(cors());

//  var f = new db();


app.get("/products", function (req, res) {
    //  console.log(db.fetchAll());
   
        //res.send(db.fetch());
           crud.fetchData('products', function(results) {
  //console.log(results);
  res.send(results);
});

});


app.get("/products/:id", function (req, res) {
    let id = req.params.id;
    con.query("SELECT * FROM products where id ="+id, (err, result, fields) => {
        if (err) throw (err);
        console.log(result);
        res.send(result);
    });
    
});


app.post("/product",jsonParser, async function (req, res) {
    // let pname = req.body.pname;
    // let price = req.body.price; 
    let inqr = `INSERT INTO products(pname, price) VALUES ('new2',6)`;
    // con.query(inqr,(err,result)=>{
    //     if(err){
    //         res.send({error:"operation failed"});
    //     }else{
    //         res.send({success:"operation complete"});
    //     }
    // });
    try {
        const result = await con.query(inqr);
        res.send(0)
      } catch(e) {
        console.log(e);
        res.send(1); //"**Error ecounterd, staff not registerd**\nPlease contact system Administrator.")
      }
     
});


app.patch("/productUpdate/:id",jsonParser, function (req, res) {
    let pname = req.body.pname;
    let price = req.body.price; 
    let id = req.params.id;
    let upqr = ` UPDATE products SET pname='${pname}',pric='${price}' WHERE id = '${id}' `;
    con.query(upqr,(err,result)=>{
        if(err){
            res.send({error:"operation failed"});
        }else{
            res.send({success:"operation complete"});
        }
    });
});

app.delete("/product/:id", function (req, res) {
    let id = req.params.id;
    let dlqr =` DELETE FROM products WHERE id = '${id}' `;
    con.query(dlqr,(err,result)=>{
        if(err){
            res.send({error:"operation failed"});
        }else{
            res.send({success:"operation complete"});
        }
    });
});


 
app.listen(3000, () => {
	
    console.log('server started');
});

