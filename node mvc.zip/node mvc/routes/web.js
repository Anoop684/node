const express = require("express");
const router = express.Router();
const userController = require("../controller/UserController");
const productController = require("../controller/ProductController");
const jwt = require("../middleware/VerifyToken");

var bodyParser = require("body-parser");

// json parser
var jsonParser = bodyParser.json();

// url encoded 
var urlEncodedParser = bodyParser.urlencoded({ extended: false });

router.post('/signup', jsonParser, userController.signup);

router.post('/login', jsonParser, userController.login);

router.get('/products', jwt.verifyToken, productController.getAll);

router.get('/products/find/:id', jwt.verifyToken, productController.getOne);

router.post('/products/save', jwt.verifyToken, jsonParser, productController.add);

router.patch('/products/update/:id', jwt.verifyToken, jsonParser, productController.update);

router.get('/logout', userController.logout);

module.exports = router;