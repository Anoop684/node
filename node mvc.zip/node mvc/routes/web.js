const express = require("express");
const router = express.Router();
const controller = require("../controller/ProductController");
var bodyParser = require("body-parser");
// json parser
var jsonParser = bodyParser.json();
router.get('/', controller.getAllProduct);
router.get('/find/:id', controller.getone);
router.post('/save',jsonParser, controller.add);

module.exports = router;